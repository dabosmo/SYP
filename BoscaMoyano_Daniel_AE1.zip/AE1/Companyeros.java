package AE1;

public class Companyeros {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String [] comps = new String[] {"Daniel", "Victor", "Alejandra", "Laura", "Javier", "Carmen"};
		
		for(int i = 0; i < 6; i++) {
			
			System.out.println(comps[i]);
		}

	}

}

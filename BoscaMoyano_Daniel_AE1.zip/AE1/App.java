package AE1;

public class App {
	
	public static void main (String args[]) {
		
		System.out.println(sayHello());
	}
	
	public static String sayHello(){
		
		String mensaje = "Hola Mundo";
		
		return mensaje;
	}
}
